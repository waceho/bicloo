package commun;

import android.app.Application;

import com.tapandgo.amancio.bicloo.R;

import java.util.ArrayList;

/**
 * Created by AmancioPCMAC on 01/02/2017.
 */

public class TabSection {

    public TabSection(String Section)
    {
        this.SECTION  = Section;

    }

    public String getSECTION() {
        return SECTION;
    }

    public void setSECTION(String SECTION) {
        this.SECTION = SECTION;
    }

    private String SECTION;





}
