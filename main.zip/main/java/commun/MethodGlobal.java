package commun;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.support.design.widget.Snackbar;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by AmancioPCMAC on 06/02/2017.
 */

public class MethodGlobal {
    public Context mContext;

    private static boolean wifiConnected = false;

    private static boolean mobileConnected = false;
    private DbController DBcontroller;
    private Global MonGlobal;
    private Constante MesConstantes = new Constante();
    private ArrayList<HashMap<String, String>> StationsList;

    public MethodGlobal(Context context){
        this.mContext = context;
        DBcontroller = new DbController(context);
        MonGlobal = (Global)this.mContext;
        StationsList = new ArrayList<HashMap<String, String>>();
    }

    // Message SnackBar ****************************************************************************************************************************************/
    public void showSnackBar(View v, String message){
        Snackbar snackbar = Snackbar
                .make(v, "Connexion Indisponible", Snackbar.LENGTH_LONG)
                .setAction("Setting", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent=new Intent(Settings.ACTION_DREAM_SETTINGS);
                         mContext.startActivity(intent);
                    }
                });

        snackbar.show();
    }

    // Vérification de la connexion Internet ******************************************************************************************************************/
    public Boolean isConnected(Context context){

         boolean Etat = false;

        ConnectivityManager connMgr =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeInfo = connMgr.getActiveNetworkInfo();
        if (activeInfo != null && activeInfo.isConnected()) {
            wifiConnected = activeInfo.getType() == ConnectivityManager.TYPE_WIFI;
            mobileConnected = activeInfo.getType() == ConnectivityManager.TYPE_MOBILE;
            if(wifiConnected) {
                    Etat = true;
            } else if (mobileConnected){
                    Etat = true;
                }

        } else {
                    Etat = false;
        }
        return Etat;
    }

    // Cette methode vérifie et retourne les adresses correspondant au mot ****************************************************************************************/
    public ArrayList<HashMap<String, String>> NearStation(ArrayList position) {
        StationsList = DBcontroller.getAllStations();
        ArrayList<HashMap<String, String>> NearPosition = new ArrayList<HashMap<String, String>>();
        if (StationsList.size() != 0 && StationsList != null) {
            double lat = Double.valueOf(position.get(0).toString());
            double lng = Double.valueOf(position.get(1).toString());
            double distanceLat = Math.abs(Double.valueOf(StationsList.get(0).get(MesConstantes.getLat())) - lat);
            double distanceLng = Math.abs(Double.valueOf(StationsList.get(0).get(MesConstantes.getLng())) - lng);
            int indexLat = 0;
            int indexLng = 0;
            for (int x = 1; x < StationsList.size(); x++) {
                double Latdistance = Math.abs(Double.valueOf(StationsList.get(x).get(MesConstantes.getLat())) - lat);
                double Lngdistance = Math.abs(Double.valueOf(StationsList.get(x).get(MesConstantes.getLng())) - lng);
                if ((Latdistance < distanceLat) && (Lngdistance < distanceLng)) {
                    indexLat = x;
                    indexLng = x;
                }
            }
            // On crée un HashMap pour la position identifiée
            HashMap<String, String> map = new HashMap<String, String>();
            map.put(MesConstantes.getLat(), StationsList.get(indexLat).get(MesConstantes.getLat()));
            map.put(MesConstantes.getLng(), StationsList.get(indexLng).get(MesConstantes.getLng()));
            NearPosition.add(map);

        }
        return NearPosition;
    }

    // vérifie et retourne les adresses correspondant au mot ***************************************************************************************************/
    public ArrayList ResultatSearch(String NewQuery){
        ArrayList ListeFound = new ArrayList();
        // On recherche uniquement à partir de trois caractères au minimum
        if (NewQuery.length() >= 3) {
            final HashMap<String, String> map = new HashMap<String, String>();
            StationsList = DBcontroller.getAllStations();
            for (int i = 0; i < StationsList.size(); i++) {
                String Address = StationsList.get(i).get(MesConstantes.getAddress());
                if (Address.toLowerCase().contains(NewQuery)) {
                    ListeFound.add(Address);
                }
            }
        }
        return ListeFound;
    }

    // recherche l'adresse de la station la plus proche *********************************************************************************************************/
    public String AddressStationProche(ArrayList<HashMap<String, String>> NearStation){
        StationsList = DBcontroller.getAllStations();
        String Address = "";
       // ArrayList<HashMap<String, String>> ListeStation = StationsList
        for (int N = 0; N < StationsList.size(); N++ ){
            // On vérifie l'adresse dans la base de donnée
            if (StationsList.get(N).get(MesConstantes.getLat()).equals(NearStation.get(0).get(MesConstantes.getLat()))){
                if (StationsList.get(N).get(MesConstantes.getLng()).equals(NearStation.get(0).get(MesConstantes.getLng()))){
                    Address = StationsList.get(N).get(MesConstantes.getAddress());
                }
            }
        }
        return Address;
    }

    /* cherche les coordonnées des adresses dans la bd ,
    *  insere et renvoie les données dans un hashMap
    */
    public HashMap<String, String> ItineraireData(String StationDepart, String StationDestination) {
        // On récupère les informations des stations
        StationsList = DBcontroller.getAllStations();
        // création HashMap et listHashMap
        HashMap<String, String> map = new HashMap<String, String>();
        // Recherche des coordonnées GPS des adresses source et destination
        for (int y=0 ; y < StationsList.size(); y++){
            if (StationDepart.equalsIgnoreCase(StationsList.get(y).get(MesConstantes.getAddress()))){
                map.put("LatDepart", StationsList.get(y).get(MesConstantes.getLat()));
            }
            if (StationDepart.equalsIgnoreCase(StationsList.get(y).get(MesConstantes.getAddress()))){
                map.put("LngDepart", StationsList.get(y).get(MesConstantes.getLng()));
            }
            if (StationDestination.equalsIgnoreCase(StationsList.get(y).get(MesConstantes.getAddress()))){
                map.put("LatDestination", StationsList.get(y).get(MesConstantes.getLat()));
            }
            if (StationDestination.equalsIgnoreCase(StationsList.get(y).get(MesConstantes.getAddress()))){
                map.put("LngDestination", StationsList.get(y).get(MesConstantes.getLng()));
            }
        }
        return map;
    }


    }
