package commun;


/**
 * Created by AmancioPCMAC on 02/02/2017.
 */

public class ContractData {

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    private String name;

}
