package commun;

/**
 * Created by AmancioPCMAC on 08/02/2017.
 */

public class Constante {

    // Déclaratin des contantes  /* ATTENTION : IL SAGIT ICI DES CLES UTILISEES ET NON DES VALEURS REELLES */

    private String number = "number";
    private String name = "name";
    private String address = "address";
    private String lat = "lat";
    private String lng = "lng";
    private String banking = "banking";
    private String bonus = "bonus";
    private String status = "status";
    private String contract_name = "contract_name";
    private String bike_stands = "bike_stands";
    private String available_bike_stands = "available_bike_stands";
    private String available_bikes = "available_bikes";
    private String last_update = "last_update";
    private String PositionKey = "PositionActuelle";
    private String LatStationDepart = "LatDepart";
    private String LatStationDestinaion = "LatDestination";
    private String LngStationDepart = "LngDepart";
    private String LngStationDestination = "LngDestination";
    public String getLngStationDestination() {
        return LngStationDestination;
    }

    public void setLngStationDestination(String lngStationDestination) {
        LngStationDestination = lngStationDestination;
    }

    public String getLngStationDepart() {
        return LngStationDepart;
    }

    public void setLngStationDepart(String lngStationDepart) {
        LngStationDepart = lngStationDepart;
    }

    public String getLatStationDestinaion() {
        return LatStationDestinaion;
    }

    public void setLatStationDestinaion(String latStationDestinaion) {
        LatStationDestinaion = latStationDestinaion;
    }

    public String getLatStationDepart() {
        return LatStationDepart;
    }

    public void setLatStationDepart(String latStationDepart) {
        LatStationDepart = latStationDepart;
    }
    public String getPositionKey() {
        return PositionKey;
    }
    public String getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getLat() {
        return lat;
    }

    public String getLng() {
        return lng;
    }

    public String getBanking() {
        return banking;
    }

    public String getBonus() {
        return bonus;
    }

    public String getStatus() {
        return status;
    }

    public String getContract_name() {
        return contract_name;
    }

    public String getBike_stands() {
        return bike_stands;
    }

    public String getAvailable_bike_stands() {
        return available_bike_stands;
    }

    public String getAvailable_bikes() {
        return available_bikes;
    }

    public String getLast_update() {
        return last_update;
    }

}
