package commun;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by AmancioPCMAC on 03/02/2017.
 */

public class DbController extends SQLiteOpenHelper {

    public DbController(Context applicationcontext) {
            super(applicationcontext,"station.db" ,null,1);
    }
        //Création de la Table stations ****************************************************************
        @Override
        public void onCreate(SQLiteDatabase database) {

            String query;
            query = "CREATE TABLE stations ( number INTEGER, " +
                    "contract_name TEXT, " +
                    "name TEXT, " +
                    "address TEXT, " +
                    "bike_stands INTEGER, " +
                    "available_bike_stands INTEGER, " +
                    "available_bikes INTEGER, " +
                    "status TEXT, " +
                    "lat DOUBLE, " +
                    "lng DOUBLE, " +
                    "banking BOOLEAN, " +
                    "bonus BOOLEAN, " +
                    "last_update TIMESTAMP)";
            database.execSQL(query);
            }
        // bd update ***********************************************************************************
        @Override
        public void onUpgrade(SQLiteDatabase database, int version_old, int current_version) {
            String query;
            query = "DROP TABLE IF EXISTS stations";
            database.execSQL(query);
            onCreate(database);
            }

              /**
              * Insertion d'une Station dans SQLite DB ***************************************************
              * @param queryValeurs
              */
        public void SaveStation(HashMap<String, String> queryValeurs) {
            SQLiteDatabase database = this.getWritableDatabase();
            ContentValues valeurs = new ContentValues();
            valeurs.put("number", queryValeurs.get("number"));
            valeurs.put("contract_name", queryValeurs.get("contract_name"));
            valeurs.put("name", queryValeurs.get("name"));
            valeurs.put("address", queryValeurs.get("address"));
            valeurs.put("bike_stands", queryValeurs.get("bike_stands"));
            valeurs.put("available_bike_stands", queryValeurs.get("available_bike_stands"));
            valeurs.put("available_bikes", queryValeurs.get("available_bikes"));
            valeurs.put("status", queryValeurs.get("status"));
            valeurs.put("lat", String.valueOf(queryValeurs.get("lat")));
            valeurs.put("lng", String.valueOf(queryValeurs.get("lng")));
            valeurs.put("banking", queryValeurs.get("banking"));
            valeurs.put("bonus", queryValeurs.get("bonus"));
            valeurs.put("last_update", queryValeurs.get("last_update"));
            database.insert("stations", null, valeurs);
            database.close();
            }



        //Récupération de la liste des Stations ************************************************************
        public ArrayList<HashMap<String, String>> getAllStations() {
            ArrayList<HashMap<String, String>> stationList;
            stationList = new ArrayList<HashMap<String, String>>();
            String selectQuery = "SELECT  * FROM stations";
            SQLiteDatabase database = getWritableDatabase();
            Cursor cursor = database.rawQuery(selectQuery, null);
              if (cursor.moveToFirst()) {
                do {
                    HashMap<String, String> map = new HashMap<String, String>();
                    map.put("number", cursor.getString(0));
                    map.put("contract_name", cursor.getString(1));
                    map.put("name", cursor.getString(2));
                    map.put("address", cursor.getString(3));
                    map.put("bike_stands", cursor.getString(4));
                    map.put("available_bike_stands", cursor.getString(5));
                    map.put("available_bikes", cursor.getString(6));
                    map.put("status", cursor.getString(7));
                    map.put("lat", cursor.getString(8));
                    map.put("lng", cursor.getString(9));
                    map.put("banking", cursor.getString(10));
                    map.put("bonus", cursor.getString(11));
                    map.put("last_update", cursor.getString(12));
                    stationList.add(map);
                    }
                while (cursor.moveToNext());
                }
            database.close();

            return stationList;
            }


    //  Delete all de la base de donnée
    public void deleteAll(){
        String deleteQuery = "DELETE FROM stations";
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL(deleteQuery);
        database.close();
    }

}


