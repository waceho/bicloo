package commun;

/**
 * Created by AMANCIOPCMAC on 03/02/2017.
 */
public class DataListView {

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    // Nom de la station
    private String Name;
    // adresse de la station
    private String adresse;

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }
}
