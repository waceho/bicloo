package commun;

import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by AmancioPCMAC on 02/02/2017.
 */

public class Global extends Application {

     // Accesseurs de la class application *********************************************************

    private ArrayList<HashMap<String, String>> ListeStationBD;
    private ArrayList<TabSection> mesSections = new ArrayList<TabSection>();
    private ArrayList<ContractData> RessourcesStation = new ArrayList<ContractData>();
    private double LatSource;

    public double getLatSource() {
        return LatSource;
    }

    public void setLatSource(double latSource) {
        LatSource = latSource;
    }

    public double getLatDestination() {
        return LatDestination;
    }

    public void setLatDestination(double latDestination) {
        LatDestination = latDestination;
    }

    public double getLngSource() {
        return LngSource;
    }

    public void setLngSource(double lngSource) {
        LngSource = lngSource;
    }

    public double getLngDestination() {
        return LngDestination;
    }

    public void setLngDestination(double lngDestination) {
        LngDestination = lngDestination;
    }

    private double LatDestination;
    private double LngSource;
    private double LngDestination;
    public ContractData getContratData(int pPosition) {return RessourcesStation.get(pPosition);}

    public void setContractData(ContractData station) {RessourcesStation.add(station);}

    public TabSection getSection(int position){return mesSections.get(position);}

    public void setSections(TabSection Section){
        mesSections.add(Section);
    }

    // retourne le nombre de Section définit dans le fichier string ---------------------------------

    public int getSectionArraylistSize() {return mesSections.size();}

    // Retourne le nombre de station ----------------------------------------------------------------
    public int getStationArraylistSize() {return RessourcesStation.size();}

    public ArrayList<HashMap<String, String>> getListeStationBD() {
        return ListeStationBD;
    }

    public void setListeStationBD(ArrayList<HashMap<String, String>> listeStationBD) {
        ListeStationBD = listeStationBD;
    }









}
