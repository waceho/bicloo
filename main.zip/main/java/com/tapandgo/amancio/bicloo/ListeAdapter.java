package com.tapandgo.amancio.bicloo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import commun.DataListView;

/**
 * Created by AmancioPCMAC on 06/02/2017.
 */

public class ListeAdapter extends ArrayAdapter<DataListView> {

    private Context context;
    private final List<DataListView> dataListViewList;

    public ListeAdapter(Context context, List<DataListView> objects) {
        super(context, R.layout.customliist, objects);
        this.context = context;
        this.dataListViewList = objects;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // définition d'une simple listVue custom

        /*
        On pourrait au mieux avoir une liste sous forme de card view avec les photos des stations |
         */
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.customliist, parent, false);
        TextView name = (TextView) rowView.findViewById(R.id.name);
        TextView adresse = (TextView) rowView.findViewById(R.id.desc);

        name.setText(dataListViewList.get(position).getName());
        adresse.setText(dataListViewList.get(position).getAdresse());
        return rowView;
    }
}
