package com.tapandgo.amancio.bicloo;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import commun.Constante;
import commun.Global;
import commun.DbController;
import commun.MethodGlobal;
import cz.msebera.android.httpclient.Header;

public class DataFromAPI extends Service {

    private int number;
    private String contract_name;
    private String name,address,status;
    private int bike_stands,available_bike_stands,available_bikes;
    private  double lat,lng;
    private boolean banking,bonus;
    private MethodGlobal MethodeGlobal;
    Context mContext;
    static ConnectivityManager cm;
    // DB Class to perform DB related operations
    DbController controleurDB = new DbController(this);
    Global global = new Global();
    Constante MesConstante = new Constante();
    HashMap<String, String> stationValues;
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.

        throw new UnsupportedOperationException("Not yet implemented");
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        cm = (ConnectivityManager)getApplication().getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        MethodeGlobal = new MethodGlobal(getApplicationContext());
        final String url = intent.getExtras().getString("url");
        if (MethodeGlobal.isConnected(getApplicationContext()) && (controleurDB.getAllStations().size() == 0 || controleurDB.getAllStations() == null)){
            Toast.makeText(getApplicationContext(),"connecté",Toast.LENGTH_SHORT).show();

            CountDownTimer timer = new CountDownTimer(5000, 10000) {
                @Override
                public void onTick(long l) {

                }

                @Override
                public void onFinish() {
                    getStationFromJDecaux(url);
                }
            }.start();

        }else {
                CountDownTimer timer = new CountDownTimer(1000, 1000) {
                @Override
                public void onTick(long l) {

                }

                @Override
                public void onFinish() {
                    lanceActivity();
                }
            }.start();

        }
        return START_NOT_STICKY;
    }
/*
    private Boolean isConnected(Context context){
        boolean state = false;
        // Check for network connections
        if (cm.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTED ||
                cm.getNetworkInfo(0).getState() == NetworkInfo.State.CONNECTING ||
                cm.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTING ||
                cm.getNetworkInfo(1).getState() == NetworkInfo.State.CONNECTED) {
                    state = true;
        }
        return state;
    }
    */
    public void getStationFromJDecaux(final String url){
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(url, new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                    getStationFromJDecaux(url);
            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                SauvegardeStations(responseString);
            }
        });
    }
    public void SauvegardeStations(String responseString){
        try {
            JSONArray JsonReponse = new JSONArray(responseString);
            int taille = JsonReponse.length();

            //  vide la base de donnée -----------------------------------------------------
            controleurDB.deleteAll();

            // ajout des nouvelles valeurs--------------------------------------------------
            for (int i =0; i<taille; i++){
                Toast.makeText(getApplicationContext(),responseString,Toast.LENGTH_SHORT).show();
                JSONObject Element = JsonReponse.getJSONObject(i);
                number = Element.getInt(MesConstante.getNumber());
                name = Element.getString(MesConstante.getName());
                address = Element.getString(MesConstante.getAddress());
                status = Element.getString(MesConstante.getStatus());
                contract_name = Element.getString(MesConstante.getContract_name());
                bike_stands = Element.getInt(MesConstante.getBike_stands());
                available_bike_stands = Element.getInt(MesConstante.getAvailable_bike_stands());
                available_bikes = Element.getInt(MesConstante.getAvailable_bikes());
                JSONObject position = Element.getJSONObject("position");
                lat = position.getDouble(MesConstante.getLat());
                lng = position.getDouble(MesConstante.getLng());
                banking = Element.getBoolean(MesConstante.getBanking());
                bonus = Element.getBoolean(MesConstante.getBonus());
                long Tlast_update = Element.getLong(MesConstante.getLast_update());
                Date dt = new Date (Tlast_update / 1000);
                SimpleDateFormat sfd = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

                // initialisation d'un HashMap pour la station
                stationValues = new HashMap<String, String>();

                // Ajout de la station extraite de l'Objet -------------------------------------------------------------
                stationValues.put(MesConstante.getNumber(), Integer.toString(number));

                // Add userName extracted from Object
                stationValues.put(MesConstante.getName(), name);
                stationValues.put(MesConstante.getAddress(), address);
                stationValues.put(MesConstante.getStatus(), status);
                stationValues.put(MesConstante.getContract_name(), contract_name);
                stationValues.put(MesConstante.getBike_stands(), Integer.toString(bike_stands) );
                stationValues.put(MesConstante.getAvailable_bike_stands(), Integer.toString(available_bike_stands));
                stationValues.put(MesConstante.getAvailable_bikes(), Integer.toString(available_bikes));
                stationValues.put(MesConstante.getLat(), String.valueOf(lat));
                stationValues.put(MesConstante.getLng(), String.valueOf(lng));
                stationValues.put(MesConstante.getBanking(), Boolean.toString(banking));
                stationValues.put(MesConstante.getBonus(), Boolean.toString(bonus));
                stationValues.put(MesConstante.getLast_update(), sfd.format(dt));
                // Fin d'Ajout de la station extraite --------------------------------------------------------------------

                // Insertionde la station dans SQLite DB
                controleurDB.SaveStation(stationValues);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }finally {

            // lancement de l'activité principale après la récupération des données
            lanceActivity();
        }
    }
    public void lanceActivity(){
        Intent start = new Intent(getBaseContext(),MainActivity.class);
        start.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getBaseContext().startActivity(start);
    }

}
