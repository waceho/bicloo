package com.tapandgo.amancio.bicloo;

import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.design.widget.CoordinatorLayout;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

import commun.Global;
import commun.DbController;

/**
 * Created by AmancioPCMAC on 01/02/2017.
 */

public class BottomSheetActivity extends BottomSheetDialogFragment{

    private Global MonGlobal;

    @Override
    public void onCreate(Bundle Save){

        super.onCreate(Save);
        // Instanciation de la class application
        MonGlobal = (Global)this.getActivity().getApplication();
    }
    private BottomSheetBehavior.BottomSheetCallback monBoutonSheet = new BottomSheetBehavior.BottomSheetCallback() {


        @Override
        public void onStateChanged(@NonNull View bottomSheet, int newState) {
            if (newState == BottomSheetBehavior.STATE_HIDDEN){
                dismiss();
            }
        }

        @Override
        public void onSlide(@NonNull View bottomSheet, float slideOffset) {

        }
    };

    @Override
    public void setupDialog(Dialog dialog, int style){
        super.setupDialog(dialog,style);
        View contenu = View.inflate(getContext(), R.layout.bottomsheetlayout,null);
        dialog.setContentView(contenu);

        TextView Titre = (TextView)dialog.findViewById(R.id.name);
        TextView adresse = (TextView)dialog.findViewById(R.id.address);
        TextView NombreAttache = (TextView)dialog.findViewById(R.id.bike_stands);
        TextView NombreAttecheDisponible = (TextView)dialog.findViewById(R.id.available_bike_stands);
        TextView NombreVelo = (TextView)dialog.findViewById(R.id.available_bikes);
        TextView statut = (TextView)dialog.findViewById(R.id.StationStatus);
        TextView StationBanking = (TextView)dialog.findViewById(R.id.banking);
        TextView StationBonus = (TextView)dialog.findViewById(R.id.bonus);

        // Argument nécessaire à la récupération des détails de la station en paramètre ************************

        Bundle MonArgument = getArguments();
        final String Numero = MonArgument.getString("NumeroStation");

        /* parcour la liste des stations dans la bd et ajoute les informations détaillés
         * de la station correspondant au numéro passé de station reçu                   ***************************** /* pourrait bien rester dans une function
         */
        ArrayList<HashMap<String, String>> ListeStation = MonGlobal.getListeStationBD();
        for (int i = 0; i <ListeStation.size(); i++) {
            if (ListeStation.get(i).get("number").equals(Numero)) {
                Titre.setText(getName(ListeStation.get(i).get("name")));
                adresse.setText(ListeStation.get(i).get("address"));
                NombreAttache.setText(ListeStation.get(i).get("bike_stands"));
                NombreAttecheDisponible.setText(ListeStation.get(i).get("available_bike_stands"));
                NombreVelo.setText(ListeStation.get(i).get("available_bikes"));
                statut.setText(ListeStation.get(i).get("status"));
                StationBanking.setText(ListeStation.get(i).get("banking"));
                StationBonus.setText(ListeStation.get(i).get("bonus"));

            }
        }
        // création du paramètre supportant le bottom sheet ***************************************************************************

        CoordinatorLayout.LayoutParams paremetres = (CoordinatorLayout.LayoutParams) ((View) contenu.getParent()).getLayoutParams();
        CoordinatorLayout.Behavior comportement = paremetres.getBehavior();

        // Définition du comportement du bottom sheet *********************************************************************************

        if(comportement != null && comportement instanceof BottomSheetBehavior){
            ((BottomSheetBehavior) comportement).setBottomSheetCallback(monBoutonSheet);
            ((BottomSheetBehavior) comportement).setPeekHeight(100);
            ((BottomSheetBehavior) comportement).setState(BottomSheetBehavior.STATE_COLLAPSED);
        }

    }
    // Traitement du nom de la station ************************************************************************************************
    public String getName(String nom){
        final String[] Tname = nom.split("-");
        final String name = Tname[1];
        return name;
    }

}
