package com.tapandgo.amancio.bicloo;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;

import android.widget.ListView;
import android.widget.Toast;

import com.arlib.floatingsearchview.FloatingSearchView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import commun.Constante;
import commun.Global;
import commun.DataListView;
import commun.DbController;
import commun.MethodGlobal;
import commun.TabSection;

public class MainActivity extends AppCompatActivity{

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;
    private static Global MonGlobal;
    private MethodGlobal MethodGlobal;
    private Toolbar toolbar;
    private DbController DBcontroller = new DbController(this);
    private TabLayout tabLayout;
    private Constante MesConsctantes = new Constante();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        //Instantiation
         MonGlobal = (Global) getApplicationContext();
        MethodGlobal = new MethodGlobal(getApplicationContext());

        TabSection Section = null;
        MonGlobal.setListeStationBD(DBcontroller.getAllStations());
        //TabSection.setListeTab(getResources().getStringArray(R.array.listeSECTION));

        tabLayout = (TabLayout) findViewById(R.id.tabs);

        // @String --> Array size
        int nombreSection = getResources().getStringArray(R.array.listeSECTION).length;

        /******************  Création des données de SECTION  | la liste des noms des tabs sont récupérés depuis @String ***********/

        for(int i = 0; i< nombreSection; i++)
        {
            Section = new TabSection(getResources().getStringArray(R.array.listeSECTION)[i]);
            // acceseurs des noms de tab ********
            MonGlobal.setSections(Section);

        }

        tabLayout.setupWithViewPager(mViewPager);
        tabLayout.setSelectedTabIndicatorHeight(6);

        // FloatingActionButton et action clique lancement Actitité Itinéraire *****************************************
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            // Intent de lancement de la connexion
                Intent startRechercheIntinéraire = new Intent(MainActivity.this, DialogItineraire.class);
                startRechercheIntinéraire.putExtra(MesConsctantes.getPositionKey(),GetLocation());
                startActivity(startRechercheIntinéraire);

            }
        });

        // Définition des icons de Tabs++***********************
        setTabIcon();;

        // Vérification de la connexion et affichage SnackBar  ***************************************
        if (!MethodGlobal.isConnected(getApplicationContext())){

            MethodGlobal.showSnackBar(tabLayout,getResources().getString(R.string.nonConnecte));

        }
    }

    // Récupératin de la position actuelle de l'utilisateur via le service dédié ******************************************
    public ArrayList GetLocation(){
        ActuelLocationProvider mylistner = new ActuelLocationProvider(this);
        ArrayList ActuelPosition = new ArrayList();
        double lat = mylistner.latitude;
        double lng = mylistner.longitude;
        ActuelPosition.add(lat);
        ActuelPosition.add(lng);
        Toast.makeText(getApplicationContext(),ActuelPosition.toString(),Toast.LENGTH_SHORT).show();
        return ActuelPosition;
    }

    // Définition des icons de tabs
    public void setTabIcon(){
    tabLayout.getTabAt(0).setIcon(R.drawable.ic_action_map);
    tabLayout.getTabAt(1).setIcon(R.drawable.ic_action_view_list);
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);

        return super.onCreateOptionsMenu(menu);

    }
    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "section_number";

        // Instanciation ---------------
        ArrayList<HashMap<String, String>> listeStationBD = MonGlobal.getListeStationBD();
        int NombreStation = listeStationBD.size();
        List<DataListView> ListDetail = new ArrayList<DataListView>();

        public PlaceholderFragment() {
        }
        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        /*
        * traitement et affichage des sections carte et liste
        *
         */

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            //  traitement et affichage  carte *********************************************************************************************************************************/

            if (getArguments().getInt(ARG_SECTION_NUMBER) == 1) {
                final View rootView = inflater.inflate(R.layout.fragment_carte, container, false);
                final MapView mMapView = (MapView) rootView.findViewById(R.id.mapView);
                mMapView.onCreate(savedInstanceState);
                mMapView.onResume();
                try {
                    MapsInitializer.initialize(getActivity().getApplicationContext());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                mMapView.getMapAsync(new OnMapReadyCallback() {
                    @Override
                    public void onMapReady(GoogleMap mMap) {

                        LatLng Station = null;
                        // On vérifie si on a au moins une station dans la base de donnée  *************************************************
                        if (NombreStation != 0){
                            for (int i  = 0 ; i < NombreStation; i++ ){
                                // Récupération des coordonnées GPS depuis la BD SQlite
                                Double lat = Double.parseDouble(String.valueOf(listeStationBD.get(i).get("lat")));
                                Double lng = Double.parseDouble(String.valueOf(listeStationBD.get(i).get("lng")));
                                Station = new LatLng(lat,lng);
                                String StationNumber = listeStationBD.get(i).get("number");
                                String Status = listeStationBD.get(i).get("status");
                                if (Status.equals("OPEN")){

                                    mMap.addMarker(new MarkerOptions().position(Station).title(StationNumber).snippet(listeStationBD.get(i).get("address"))
                                            .flat(true)
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.mappin_open))
                                    );
                                }else {
                                    mMap.addMarker(new MarkerOptions().position(Station).title(StationNumber).snippet(listeStationBD.get(i).get("address"))
                                            .flat(true)
                                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.mappin))
                                    );
                                }

                                CameraPosition cameraPosition = new CameraPosition.Builder().target(Station).zoom(14).build();
                                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }
                        }else {
                            Snackbar snackbar = Snackbar
                                    .make(getView(), "Connexion Indisponible", Snackbar.LENGTH_LONG)
                                    .setAction("Setting", new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            Intent intent=new Intent(Settings.ACTION_DREAM_SETTINGS);
                                            startActivity(intent);
                                        }
                                    });

                            snackbar.show();
                        }

                        // For zooming automatically to the location of the marker
//
                        mMap.setTrafficEnabled(true);

                        // For dropping a marker at a point on the Map
                        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                            @Override
                            public boolean onMarkerClick(Marker marker) {
                                String NumeroStation = marker.getTitle();
                                lanceBottomSheet(NumeroStation,-1);
                                return true;
                            }
                        });
                    }
                });

                return rootView;
            }
            /*
            * affichage par liste -----------------------------------------------------------------------------------------------------------------------------------
            *
             */
            if (getArguments().getInt(ARG_SECTION_NUMBER) == 2) {
                View rootView = inflater.inflate(R.layout.fragment_liste, container, false);
                ListView desc = (ListView) rootView.findViewById(R.id.listStation);
                desc.setFastScrollEnabled(true);
                desc.setOverScrollMode(AbsListView.OVER_SCROLL_IF_CONTENT_SCROLLS);
                for (int i = 0; i < NombreStation; i++) {
                    DataListView dataListView = new DataListView();

                    dataListView.setName(getName(listeStationBD.get(i).get("name")));
                    dataListView.setAdresse(listeStationBD.get(i).get("address"));
                    ListDetail.add(dataListView);
                }

                desc.setAdapter(new ListeAdapter(getActivity(),ListDetail));
                desc.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        lanceBottomSheet(null,i);

                    }
                });
                return rootView;
            }
            return super.getView();
        }
        /*
        * Traitement du nom de la station -----------------------------------------------------------
        *
         */
        public String getName(String nom){
           final String[] Tname = nom.split("-");
           final String name = Tname[1];
            return name;
        }
        // ------------------------------------------------------------------------------------------


        public void lanceBottomSheet(String number, int index){
            if (number != null){
                Bundle args = new Bundle();
                args.putString("NumeroStation", number);
                BottomSheetDialogFragment bottomSheet = new BottomSheetActivity();
                bottomSheet.setArguments(args);
                bottomSheet.show(getFragmentManager(),bottomSheet.getTag());
            } else if(index >= 0){
                Bundle args = new Bundle();
                String numero = listeStationBD.get(index).get("number");
                args.putString("NumeroStation", numero);
                BottomSheetDialogFragment bottomSheet = new BottomSheetActivity();
                bottomSheet.setArguments(args);
                bottomSheet.show(getFragmentManager(),bottomSheet.getTag());
            }

        }
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return PlaceholderFragment.newInstance(position + 1);
        }

        @Override
        public int getCount() {
            // Show 3 total pages.

            return getResources().getStringArray(R.array.listeSECTION).length;
        }
        // retour dynamique du titre de la section
        @Override
        public CharSequence getPageTitle(int position) {

            return MonGlobal.getSection(position).getSECTION();

        }
    }



}
