package com.tapandgo.amancio.bicloo;

import android.app.DialogFragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import commun.Constante;
import commun.Global;
import commun.MethodGlobal;
import commun.ParserJSON;


/**
 * Created by AmancioPCMAC on 08/02/2017.
 */

public class DialogItineraire extends AppCompatActivity {
     private ArrayList actuelPosition = new ArrayList();
    private double lng;
    private double lat;
    private MapView mMapView;
    private GoogleMap mMap;
    private Constante MesConstante = new Constante();
    private MethodGlobal GlobalMethod;
    private Toolbar toolbar;
    private EditText AddrDepart;
    private EditText AddrDestination;
    private ArrayAdapter<String> adapter;
    private ListView ListAdress;
    private FloatingActionButton LanceItinéraire;
    private Global MonGlobal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialogitineraire);
        MonGlobal = (Global)getApplicationContext();
        actuelPosition = getIntent().getExtras().getCharSequenceArrayList(MesConstante.getPositionKey());
        GlobalMethod = new MethodGlobal(getApplicationContext());
        // toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbarDItineraire);

        if (toolbar != null) {
            setSupportActionBar(toolbar);
            toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);

        }
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        AddrDepart = (EditText)findViewById(R.id.depart);
        AddrDestination = (EditText)findViewById(R.id.destination);
        ListAdress = (ListView) findViewById(R.id.listStation);
        LanceItinéraire = (FloatingActionButton)findViewById(R.id.LanceItineraire);
        mMapView = (MapView) findViewById(R.id.mapItineraire);
        AddrDepart.setText(GlobalMethod.AddressStationProche(GlobalMethod.NearStation(actuelPosition)));

        LanceItinéraire.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                HashMap<String, String> ItineraireData = GlobalMethod.ItineraireData(AddrDepart.getText().toString(),AddrDestination.getText().toString());
                Toast.makeText(getApplicationContext(),ItineraireData.toString(),Toast.LENGTH_SHORT).show();
                final double latSource = Double.valueOf(ItineraireData.get(MesConstante.getLatStationDepart()));
                final double lngSource = Double.valueOf(ItineraireData.get(MesConstante.getLngStationDepart()));
                final double latDestination = Double.valueOf(ItineraireData.get(MesConstante.getLatStationDestinaion()));
                final double lngDestination = Double.valueOf(ItineraireData.get(MesConstante.getLngStationDestination()));

     // Thread de lancemnt de la recherche de l'itinéraire et
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                       new ItineraireAsyncTask(makeURL(latSource,lngSource,latDestination,lngDestination));
                    }
                }).run();
            }
        });

        // Définition de mon écouteur de saisie
        AddrDestination.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String saisi = AddrDestination.getText().toString();
               if (saisi.length() >= 3){
                   SuggestionList(saisi);
               }

            }
        });
            AddrDepart.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }

                @Override
                public void afterTextChanged(Editable editable) {
                    String saisi = AddrDepart.getText().toString();
                    if (saisi.length() >= 3){
                        SuggestionList(saisi);
                    }
                }
            });
        /* définition de l'action du clique sur un item
        *  affichage de l'adresse dans l'editText
         */
        ListAdress.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // ListView Clicked item value
                    String  itemValue  = (String)ListAdress.getItemAtPosition(i);
                    // Ajout de l'adresse à l'editText
                    AddrDestination.setText(itemValue);
                    adapter.clear();
                    ListAdress.setAdapter(adapter);
                }
        });

    }
    // methode de récuération des adresses suggéré et affichage de la SimpleListView -----------------------------------------------
    public void SuggestionList(String Query){
        // récupération des adresses trouvé
        ArrayList ListeAdress = GlobalMethod.ResultatSearch(Query);
        // définition de mon adaptater pour la liste
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, ListeAdress);
        // On assigne l'adaptateur à la listView
        ListAdress.setAdapter(adapter);

    }

    // formation de des données pour le format url de google directions
    public String makeURL (double sourcelat, double sourcelog, double destlat, double destlog ){
        StringBuilder urlString = new StringBuilder();
        urlString.append("https://maps.googleapis.com/maps/api/directions/json");
        urlString.append("?origin=");// de
        urlString.append(Double.toString(sourcelat));
        urlString.append(",");
        urlString
                .append(Double.toString( sourcelog));
        urlString.append("&destination=");// à
        urlString
                .append(Double.toString( destlat));
        urlString.append(",");
        urlString.append(Double.toString( destlog));
        urlString.append("&sensor=false&mode=driving&alternatives=true");
        urlString.append("&key="+getResources().getString(R.string.Google_Maps_API_KEY));
        return urlString.toString();
    }
    public void drawPath(String  result) {

        try {
            // Convertion d'un string enJSON
            final JSONObject json = new JSONObject(result);
            JSONArray routeArray = json.getJSONArray("routes");
            JSONObject routes = routeArray.getJSONObject(0);
            JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
            String encodedString = overviewPolylines.getString("points");
            final List<LatLng> list = decodePoly(encodedString);
            mMapView = (MapView)findViewById(R.id.mapItineraire);
            /*
            final Polyline line = mMap.addPolyline(new PolylineOptions()
                    .addAll(list)
                    .width(12)
                    .color(Color.parseColor("#05b1fb"))//Google maps blue color
                    .geodesic(true)
            );
            */
            mMapView.getMapAsync(new OnMapReadyCallback() {
                @Override
                public void onMapReady(GoogleMap googleMap) {
                    googleMap.addPolyline(new PolylineOptions()
                            .addAll(list)
                            .width(12)
                            .color(Color.parseColor("#05b1fb"))//Google maps blue color
                            .geodesic(true)
                    );
                }
            });
           /*
           for(int z = 0; z<list.size()-1;z++){
                LatLng src= list.get(z);
                LatLng dest= list.get(z+1);
                Polyline line = mMap.addPolyline(new PolylineOptions()
                .add(new LatLng(src.latitude, src.longitude), new LatLng(dest.latitude,   dest.longitude))
                .width(2)
                .color(Color.BLUE).geodesic(true));
            }
           */
        }
        catch (JSONException e) {

        }
    }
    private List<LatLng> decodePoly(String encoded) {

        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng( (((double) lat / 1E5)),
                    (((double) lng / 1E5) ));
            poly.add(p);
        }

        return poly;
    }
    // class async de requete d'itinéraire
    private class ItineraireAsyncTask extends AsyncTask<Void, Void, String> {
        private ProgressDialog progressDialog;
        String url;
        ItineraireAsyncTask(String urlPass){
            url = urlPass;
        }
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            super.onPreExecute();
            progressDialog = new ProgressDialog(DialogItineraire.this);
            progressDialog.setMessage("Définition de la route, Veuillez patienter...");
            progressDialog.setIndeterminate(true);
            progressDialog.show();
        }
        @Override
        protected String doInBackground(Void... params) {
            ParserJSON jParser = new ParserJSON();
            String json = jParser.getJSONFromUrl(url);
            return json;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Toast.makeText(getApplicationContext(),"test",Toast.LENGTH_SHORT).show();
            progressDialog.hide();
            if(result!=null){
                drawPath(result);
            }
        }
    }
}
